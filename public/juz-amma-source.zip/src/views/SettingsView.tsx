import React, { useState, useEffect } from 'react';
import { Settings, Download, Trash2, Smartphone, HardDrive, Volume2, Type, Check, RefreshCw, Upload, Sparkles } from 'lucide-react';
import { UserSettings, UserProgress } from '../types';
import { WARSH_RECITERS, getSurahAudioUrl } from '../data/reciters';
import { clearAudioCache, getAllCachedAudios, exportUserData, importUserData } from '../services/storage';
import { promptPwaInstall, subscribeToInstallPrompt } from '../services/pwa';
import { useAudio } from '../context/AudioContext';

interface SettingsViewProps {
  settings: UserSettings;
  progress: UserProgress;
  onUpdateSettings: (newSettings: UserSettings) => void;
  onResetProgress: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  progress,
  onUpdateSettings,
  onResetProgress
}) => {
  const { setReciter } = useAudio();
  const [canInstallPwa, setCanInstallPwa] = useState(false);
  const [cachedAudiosCount, setCachedAudiosCount] = useState(0);
  const [cachedSizeBytes, setCachedSizeBytes] = useState(0);
  const [isExporting, setIsExporting] = useState(false);
  const [importMessage, setImportMessage] = useState<string | null>(null);

  useEffect(() => {
    const unsub = subscribeToInstallPrompt(can => setCanInstallPwa(can));
    loadCacheStats();
    return unsub;
  }, []);

  const loadCacheStats = async () => {
    const records = await getAllCachedAudios();
    setCachedAudiosCount(records.length);
    const totalBytes = records.reduce((acc, r) => acc + (r.sizeBytes || 0), 0);
    setCachedSizeBytes(totalBytes);
  };

  const handleClearCache = async () => {
    if (confirm('Voulez-vous vraiment vider le cache des fichiers audio hors-ligne ?')) {
      await clearAudioCache();
      await loadCacheStats();
    }
  };

  const handleInstallPwa = async () => {
    await promptPwaInstall();
  };

  const handleExportData = async () => {
    setIsExporting(true);
    const jsonStr = await exportUserData();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `juz_amma_warsh_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setIsExporting(false);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async event => {
      const content = event.target?.result as string;
      const ok = await importUserData(content);
      if (ok) {
        setImportMessage('Données importées avec succès ! Rechargez la page.');
        setTimeout(() => window.location.reload(), 1500);
      } else {
        setImportMessage('Erreur lors de la lecture du fichier de sauvegarde.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 pb-28">
      {/* Header */}
      <div className="w-full rounded-3xl bg-[#1F4D3D] text-[#FAF6EC] p-5 sm:p-7 border border-[#C9A24B]/30 shadow-xl space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#C9A24B] text-[#14332A] text-xs font-bold uppercase tracking-wider shadow-sm">
          <Settings className="w-3.5 h-3.5" />
          <span>Paramètres & Préférences</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
          Configuration de votre Application
        </h1>
        <p className="text-xs sm:text-sm text-[#FAF6EC]/80 leading-relaxed">
          Personnalisez votre récitateur Warsh, la taille de la calligraphie, le mode hors-ligne et vos données locales.
        </p>
      </div>

      {/* 1. PWA Installation Section */}
      <div className="w-full rounded-3xl p-6 bg-white dark:bg-[#16221C] border border-[#14332A]/10 dark:border-stone-800 shadow-md space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#14332A] text-[#C9A24B] flex items-center justify-center">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-extrabold text-[#14332A] dark:text-[#FAF6EC]">
              Application Mobile & Installation PWA
            </h2>
            <p className="text-xs text-stone-500">
              Installez l'application sur votre écran d'accueil pour un accès instantané sans barre de navigateur.
            </p>
          </div>
        </div>

        {canInstallPwa ? (
          <button
            onClick={handleInstallPwa}
            className="w-full py-3 rounded-2xl bg-[#C9A24B] text-[#14332A] font-extrabold text-sm hover:bg-[#d8b056] transition-all shadow-md flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>Installer l'application sur cet appareil</span>
          </button>
        ) : (
          <div className="p-4 rounded-2xl bg-stone-50 dark:bg-stone-900/60 border border-stone-200 dark:border-stone-800 text-xs text-stone-600 dark:text-stone-300 space-y-2">
            <p className="font-semibold text-[#14332A] dark:text-[#FAF6EC]">
              Pour installer sur iPhone / iPad (iOS Safari) :
            </p>
            <p>1. Touchez le bouton Partager <span className="font-bold">⎋</span> en bas de Safari.</p>
            <p>2. Faites défiler et sélectionnez <span className="font-bold">« Sur l'écran d'accueil »</span>.</p>
            <p className="text-[11px] text-stone-400 pt-1">
              Sur Android / PC : Utilisez le menu de Chrome ou Edge « Installer l'application ».
            </p>
          </div>
        )}
      </div>

      {/* 2. Reciter Selection */}
      <div className="w-full rounded-3xl p-6 bg-white dark:bg-[#16221C] border border-[#14332A]/10 dark:border-stone-800 shadow-md space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#14332A] text-[#C9A24B] flex items-center justify-center">
            <Volume2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-extrabold text-[#14332A] dark:text-[#FAF6EC]">
              Récitateur Warsh par Défaut
            </h2>
            <p className="text-xs text-stone-500">
              Les 9 récitateurs vérifiés en transmission Warsh 'an Nâfi'.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {WARSH_RECITERS.map(reciter => {
            const isSelected = settings.preferredReciterId === reciter.id;
            return (
              <div
                key={reciter.id}
                onClick={() => {
                  onUpdateSettings({ ...settings, preferredReciterId: reciter.id });
                  setReciter(reciter.id);
                }}
                className={`p-4 rounded-2xl border cursor-pointer transition-all space-y-2 ${
                  isSelected
                    ? 'bg-[#1F4D3D]/10 dark:bg-[#1F4D3D]/40 border-[#C9A24B] ring-1 ring-[#C9A24B]'
                    : 'border-[#14332A]/10 dark:border-stone-800 hover:border-[#C9A24B]/40'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-[#14332A] dark:text-[#FAF6EC]">
                    {reciter.name}
                  </span>
                  {isSelected && <Check className="w-4 h-4 text-[#C9A24B]" />}
                </div>
                <p className="font-quran text-sm text-[#C9A24B]">{reciter.subname}</p>
                <p className="text-xs text-stone-500 leading-relaxed">{reciter.description}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. Typography & Font Size Slider */}
      <div className="w-full rounded-3xl p-6 bg-white dark:bg-[#16221C] border border-[#14332A]/10 dark:border-stone-800 shadow-md space-y-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#14332A] text-[#C9A24B] flex items-center justify-center">
            <Type className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-extrabold text-[#14332A] dark:text-[#FAF6EC]">
              Taille de la Calligraphie Arabe
            </h2>
            <p className="text-xs text-stone-500">
              Ajustez la taille du texte pour un confort de lecture optimal sur votre écran.
            </p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs font-bold text-stone-600 dark:text-stone-400">
            <span>Petite (24px)</span>
            <span className="text-[#C9A24B]">{settings.arabicFontSize} px</span>
            <span>Très grande (44px)</span>
          </div>

          <input
            type="range"
            min="24"
            max="44"
            step="2"
            value={settings.arabicFontSize}
            onChange={e => onUpdateSettings({ ...settings, arabicFontSize: parseInt(e.target.value, 10) })}
            className="w-full h-2 bg-stone-200 dark:bg-stone-700 rounded-lg appearance-none cursor-pointer accent-[#C9A24B]"
          />

          {/* Preview Box */}
          <div className="p-4 rounded-2xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/40 text-center w-full">
            <p
              dir="rtl"
              style={{ fontSize: `${settings.arabicFontSize}px`, lineHeight: 2 }}
              className="font-quran text-[#14332A] dark:text-[#FAF6EC]"
            >
              بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ
            </p>
            <p className="text-xs text-stone-500 mt-1 italic">
              Exemple d'affichage en taille réelle
            </p>
          </div>
        </div>
      </div>

      {/* 4. Offline Storage Management */}
      <div className="w-full rounded-3xl p-6 bg-white dark:bg-[#16221C] border border-[#14332A]/10 dark:border-stone-800 shadow-md space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#14332A] text-[#C9A24B] flex items-center justify-center">
            <HardDrive className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-extrabold text-[#14332A] dark:text-[#FAF6EC]">
              Gestion du Stockage Hors-Ligne (IndexedDB)
            </h2>
            <p className="text-xs text-stone-500">
              Contrôlez les sourates pré-téléchargées et l'espace mémoire utilisé.
            </p>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-stone-50 dark:bg-stone-900/60 border border-stone-200 dark:border-stone-800 flex items-center justify-between">
          <div>
            <span className="font-bold text-sm text-[#14332A] dark:text-[#FAF6EC] block">
              {cachedAudiosCount} sourate{cachedAudiosCount > 1 ? 's' : ''} en mémoire hors-ligne
            </span>
            <span className="text-xs text-stone-500">
              Espace occupé : {(cachedSizeBytes / (1024 * 1024)).toFixed(2)} Mo
            </span>
          </div>

          <button
            onClick={handleClearCache}
            disabled={cachedAudiosCount === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-rose-300 dark:border-rose-800 text-rose-600 dark:text-rose-400 text-xs font-bold disabled:opacity-40 hover:bg-rose-50"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Vider le cache</span>
          </button>
        </div>

        {/* Export / Import Data */}
        <div className="pt-2 border-t border-stone-100 dark:border-stone-800 space-y-3">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              onClick={handleExportData}
              disabled={isExporting}
              className="w-full sm:w-auto px-4 py-2 rounded-xl bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-200 text-xs font-bold hover:bg-stone-200 flex items-center justify-center gap-2"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Exporter ma progression (Sauvegarde JSON)</span>
            </button>

            <label className="w-full sm:w-auto px-4 py-2 rounded-xl bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-200 text-xs font-bold hover:bg-stone-200 flex items-center justify-center gap-2 cursor-pointer">
              <Upload className="w-3.5 h-3.5" />
              <span>Restaurer une sauvegarde</span>
              <input type="file" accept=".json" onChange={handleImportFile} className="hidden" />
            </label>
          </div>

          {importMessage && (
            <p className="text-xs font-semibold text-emerald-600 text-center">{importMessage}</p>
          )}
        </div>
      </div>

      {/* 5. Export Project for Free Web Hosting (Vercel, Cloudflare, etc.) */}
      <div className="w-full rounded-3xl p-6 bg-gradient-to-br from-[#14332A]/5 via-white to-amber-500/5 dark:from-[#16221C] dark:to-stone-900 border-2 border-[#C9A24B]/30 shadow-md space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#C9A24B] text-[#14332A] flex items-center justify-center shadow-sm">
            <Download className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-extrabold text-[#14332A] dark:text-[#FAF6EC]">
              Exporter le Projet pour Hébergement Gratuit (Vercel, Cloudflare, etc.)
            </h2>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              Téléchargez l'application prête à être mise en ligne gratuitement et sans limite de crédit.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          {/* Card 1: Built dist ready for deployment */}
          <a
            href="/juz-amma-site-pre-a-publier.zip"
            download="juz-amma-site-pre-a-publier.zip"
            className="flex flex-col justify-between p-4 rounded-2xl bg-white dark:bg-[#16221C] border border-[#C9A24B]/40 hover:border-[#C9A24B] transition-all shadow-sm group hover:shadow-md"
          >
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                  Prêt en 30 sec
                </span>
                <span className="text-xs font-mono text-stone-400">274 Ko</span>
              </div>
              <h3 className="font-extrabold text-sm text-[#14332A] dark:text-[#FAF6EC] group-hover:text-[#C9A24B] transition-colors">
                Site Compilé (Prêt à publier)
              </h3>
              <p className="text-xs text-stone-500 leading-relaxed">
                Compatible <b>Vercel</b>, <b>Cloudflare Pages</b>, <b>Surge.sh</b> ou <b>Tiiny.host</b> (glisser-déposer sans configuration).
              </p>
            </div>
            <div className="mt-4 flex items-center gap-2 text-xs font-bold text-[#C9A24B]">
              <Download className="w-4 h-4" />
              <span>Télécharger le ZIP compilé</span>
            </div>
          </a>

          {/* Card 2: Full Source code */}
          <a
            href="/juz-amma-source.zip"
            download="juz-amma-source.zip"
            className="flex flex-col justify-between p-4 rounded-2xl bg-white dark:bg-[#16221C] border border-stone-200 dark:border-stone-800 hover:border-[#C9A24B] transition-all shadow-sm group hover:shadow-md"
          >
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300">
                  Code Source
                </span>
                <span className="text-xs font-mono text-stone-400">185 Ko</span>
              </div>
              <h3 className="font-extrabold text-sm text-[#14332A] dark:text-[#FAF6EC] group-hover:text-[#C9A24B] transition-colors">
                Sources Complètes (GitHub / Vercel)
              </h3>
              <p className="text-xs text-stone-500 leading-relaxed">
                Tout le code source configuré avec <b>vercel.json</b> et <b>netlify.toml</b> inclus.
              </p>
            </div>
            <div className="mt-4 flex items-center gap-2 text-xs font-bold text-[#14332A] dark:text-[#FAF6EC] group-hover:text-[#C9A24B] transition-colors">
              <Download className="w-4 h-4" />
              <span>Télécharger les sources (ZIP)</span>
            </div>
          </a>
        </div>
      </div>
    </div>
  );
};
